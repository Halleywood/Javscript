from github_app.config.mysqlconnection import connectToMySQL
from github_app.models import model
import re

class User():
    def __init__(self, data):
        super().__init__(data)

    @staticmethod
    def validate(data):
        errors={}

        if len(data['first_name']) < 1:
            errors['err_user_first_name'] = "first name is required"
        if len(data['last_name']) < 1:
            errors['err_user_last_name'] = "first name is required"
        if len(data['email']) < 1:
            errors['err_user_email'] = "first name is required"
        return errors