console.log("hello")

//get user form data///////////////////////////////////////////
var user_info=document.querySelector('.user_info')
var testBtn =document.querySelector('.test-btn')
var testBtn2 =document.querySelector('.test-btn2')
var userForm=document.querySelector('#user-form')

userForm.addEventListener('submit', function(e){
    e.preventDefault()
    console.log('form submit')

    var theForm = new FormData(userForm)
    console.log("hello1")
    fetch('/api.github.com/users/', {
        method: 'POST',
        body: theForm
    })
    .then(response => response.json())
    .then(data=>{
        console.log(data);
        if(data['status']===200){
            console.log("yes");
            var msg= data['msg'];
            firstNameErr=document.querySelector('#first_name_error')
            firstNameErr.innerText=msg 
        }
        else if(data['status']===400){
            var errorMsg = data['msg']
            errorsEl = document.querySelector('#errors')
            for (const key in errorMsg){
                console.log(key);
                errorsEl.innterHTML += '<p>${errorMsg[key]}</p>'
            }
        }
    })
    console.log("hello3")
})

//get user avatar URL////////////////////////////////////////////
let button=document.getElementById('imgbutton')
let image=document.getElementById('thisone')
let followers=document.getElementById('followers')

button.addEventListener("click", function(){
    fetch('https://api.github.com/users/adion81')
    .then(response => response.json())
    .then(data=>{
        console.log(data);
        followers.innerText=("Adrien has"+ data.followers + "followers")
        image.src=(data.avatar_url)
        data.choice
    })
})

//get input from user to select data
async function start(){
    const response= await fetch("https://dog.ceo/api/breeds/list/all") //until promise returns
    const data = await response.json() //takes API response turns into JSON object
    createBreedList(data.message)
}
start();

function createBreedList(breedList) {
    document.getElementById("breed").innerHTML=`
    <select onchange="loadByBreed(this.value)">
        <option>Choose a dog breed</option>
        ${Object.keys(breedList).map(function(breed){
            return `<option>${breed}</option>`
        }).join('')}
    </select>
    `
}

let dogpic=document.getElementById('dog')
async function loadByBreed(breed){
    try{
    if(breed != "choose a dog breed"){
        const response=await fetch(`https://dog.ceo/api/breed/${breed}/images`)
        const data= await response.json()
        console.log(data)
        dogpic.src=data.message[0]
    } 
}
    catch (e){
        console.log("there was a problem fetching breedlist!")
    }
}