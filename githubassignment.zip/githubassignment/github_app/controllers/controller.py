from flask import render_template, request, redirect, session, flash, jsonify
from github_app import app
from github_app.models import model 

@app.route('/')
def index():
    return render_template('index.html')

# @app.route('/api.github.com/users/', methods=['POST'])
# def api_user():

#     errors = model.User.validate(request.form)
#     if len(errors) > 0:
#         msg= {
#             'status': 400,
#             'msg': errors
#         }
#         return jsonify(msg)

#     print(request.form)
#     print("*************test*******************")   
#     msg={
#         'status':200,
#         'msg':'this i a message'
#     }
#     return jsonify()
# @app.route('/api.github.com/users/')
# def api_user():
#     print("getting here")
#     return jsonify()

@app.route('/api.github.com/users/', methods=['POST'])
def api_user():
    print("getting here")
    return jsonify()