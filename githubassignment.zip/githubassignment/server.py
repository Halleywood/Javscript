from github_app import app
from github_app.controllers import controller


if __name__ == "__main__":
    app.run(debug=True)